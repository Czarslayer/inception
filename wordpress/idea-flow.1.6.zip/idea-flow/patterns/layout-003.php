<?php
/**
 * Title: Layout 003
 * Slug: idea-flow/layout-003
 * Categories: layouts
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|superbspacing-xsmall","bottom":"var:preset|spacing|superbspacing-xsmall","left":"var:preset|spacing|superbspacing-small","right":"var:preset|spacing|superbspacing-small"},"blockGap":"var:preset|spacing|superbspacing-xsmall","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--superbspacing-xsmall);padding-right:var(--wp--preset--spacing--superbspacing-small);padding-bottom:var(--wp--preset--spacing--superbspacing-xsmall);padding-left:var(--wp--preset--spacing--superbspacing-small)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|superbspacing-small","left":"var:preset|spacing|superbspacing-small"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","id":2028,"width":"160px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/layout/logo-example-1.png");?>" alt="" class="wp-image-2028" style="width:160px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","id":2028,"width":"160px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/layout/logo-example-2.png");?>" alt="" class="wp-image-2028" style="width:160px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","id":2028,"width":"160px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/layout/logo-example-3.png");?>" alt="" class="wp-image-2028" style="width:160px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","id":2028,"width":"160px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/layout/logo-example-4.png");?>" alt="" class="wp-image-2028" style="width:160px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","id":2028,"width":"160px","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full is-resized"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/layout/logo-example-5.png");?>" alt="" class="wp-image-2028" style="width:160px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->