<?php
/**
 * Title: Team 002
 * Slug: idea-flow/team-002
 * Categories: teams
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|superbspacing-medium","bottom":"var:preset|spacing|superbspacing-medium","left":"var:preset|spacing|superbspacing-small","right":"var:preset|spacing|superbspacing-small"},"blockGap":"var:preset|spacing|superbspacing-small","margin":{"top":"0","bottom":"0"}}},"backgroundColor":"mono-4","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-mono-4-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--superbspacing-medium);padding-right:var(--wp--preset--spacing--superbspacing-small);padding-bottom:var(--wp--preset--spacing--superbspacing-medium);padding-left:var(--wp--preset--spacing--superbspacing-small)"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xxsmall"}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"textAlign":"left","level":3,"textColor":"primary","fontSize":"superbfont-small"} -->
<h3 class="wp-block-heading has-text-align-left has-primary-color has-text-color has-superbfont-small-font-size">Our Work</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","textColor":"contrast","fontSize":"superbfont-xlarge"} -->
<h2 class="wp-block-heading has-text-align-center has-contrast-color has-text-color has-superbfont-xlarge-font-size">Client Cases</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","textColor":"mono-2","fontSize":"superbfont-small"} -->
<p class="has-text-align-center has-mono-2-color has-text-color has-superbfont-small-font-size">Lorem ipsum dolor sit amet, consectetur adipiscing elit,<br>donec congue lorem ut volutpat efficitur.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|superbspacing-xlarge","left":"var:preset|spacing|superbspacing-small"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/team/fashion.png");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","level":3,"textColor":"contrast","fontSize":"superbfont-medium"} -->
<h3 class="wp-block-heading has-text-align-left has-contrast-color has-text-color has-superbfont-medium-font-size">Fashion Brand</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"left","style":{"spacing":{"margin":{"top":"var:preset|spacing|superbspacing-xxsmall","bottom":"var:preset|spacing|superbspacing-xxsmall"}}},"textColor":"mono-2","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-left has-mono-2-color has-text-color has-superbfont-xsmall-font-size" style="margin-top:var(--wp--preset--spacing--superbspacing-xxsmall);margin-bottom:var(--wp--preset--spacing--superbspacing-xxsmall)">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec congue lorem ut volutpat efficitur. Fusce justo magna, condimentum nec elementum sed, sollicitudin vitae enim. Vivamus sit amet metus porttitor, rhoncus nibh et, venenatis turpis. Etiam lobortis semper ante, quis luctus lacus tincidunt vel.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/team/outdoor.png");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","level":3,"textColor":"contrast","fontSize":"superbfont-medium"} -->
<h3 class="wp-block-heading has-text-align-left has-contrast-color has-text-color has-superbfont-medium-font-size">Ourdoor Brand</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"left","style":{"spacing":{"margin":{"top":"var:preset|spacing|superbspacing-xxsmall","bottom":"var:preset|spacing|superbspacing-xxsmall"}}},"textColor":"mono-2","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-left has-mono-2-color has-text-color has-superbfont-xsmall-font-size" style="margin-top:var(--wp--preset--spacing--superbspacing-xxsmall);margin-bottom:var(--wp--preset--spacing--superbspacing-xxsmall)">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec congue lorem ut volutpat efficitur. Fusce justo magna, condimentum nec elementum sed, sollicitudin vitae enim. Vivamus sit amet metus porttitor, rhoncus nibh et, venenatis turpis. Etiam lobortis semper ante, quis luctus lacus tincidunt vel.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"scale":"cover","sizeSlug":"large","linkDestination":"none","style":{"border":{"radius":"8px"}}} -->
<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url(get_template_directory_uri() . "/assets/images/team/fitness.png");?>" alt="" style="border-radius:8px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|superbspacing-xsmall"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","level":3,"textColor":"contrast","fontSize":"superbfont-medium"} -->
<h3 class="wp-block-heading has-text-align-left has-contrast-color has-text-color has-superbfont-medium-font-size">Fitness Brand</h3>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"left","style":{"spacing":{"margin":{"top":"var:preset|spacing|superbspacing-xxsmall","bottom":"var:preset|spacing|superbspacing-xxsmall"}}},"textColor":"mono-2","fontSize":"superbfont-xsmall"} -->
<p class="has-text-align-left has-mono-2-color has-text-color has-superbfont-xsmall-font-size" style="margin-top:var(--wp--preset--spacing--superbspacing-xxsmall);margin-bottom:var(--wp--preset--spacing--superbspacing-xxsmall)">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec congue lorem ut volutpat efficitur. Fusce justo magna, condimentum nec elementum sed, sollicitudin vitae enim. Vivamus sit amet metus porttitor, rhoncus nibh et, venenatis turpis. Etiam lobortis semper ante, quis luctus lacus tincidunt vel.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->